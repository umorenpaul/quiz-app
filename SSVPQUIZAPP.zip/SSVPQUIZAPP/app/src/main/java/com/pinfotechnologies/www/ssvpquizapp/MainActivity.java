package com.pinfotechnologies.www.ssvpquizapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int scores = 0;
    String finaResultsDisplay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * this method handles processing of all the correct answers
     * selected by users and calculate the total correct answers
     *
     * @param view
     */
    public void submitAnswer(View view) {
        int answer1Mark = 0;
        int answer2Mark=0;
        int answer3Mark=0;
        int answer4Mark=0;
        int answer5Mark=0;
        int answer6Mark=0;
        int answer7Mark=0;
        int answer8Mark=0;
        int answer9Mark=0;
        int answer10Mark=0;
        int totalMarks;

        // question one answers options
        boolean answer1;
        RadioButton ansOneARadioButtonA= (RadioButton) this.findViewById(R.id.qtn_one_radio_button_a);
        answer1 = ansOneARadioButtonA.isChecked();
        if (answer1) {
            answer1Mark = 2;
        }

        // question two answer options

         boolean correctAns2;
        RadioButton ansTwoARadioButtonB= (RadioButton) findViewById(R.id.qtn_two_radio_button_b);

        correctAns2 = ansTwoARadioButtonB.isChecked();
        if (correctAns2) {
            answer2Mark = 2;
        }

        // question three answer options

        EditText ansField = (EditText)findViewById(R.id.ans3_field);
        String     answer  =  ansField.getText().toString();

        if(answer.equals("Blessed Federick Ozanam")){
            answer3Mark=2;
        }


        // question four answer options
        CheckBox ansFourCheckBoxA= (CheckBox) findViewById(R.id.qtn4_checkbox_a);
        CheckBox ansFourCheckBoxB= (CheckBox) findViewById(R.id.qtn4_checkbox_b);
        CheckBox ansFourCheckBoxC= (CheckBox) findViewById(R.id.qtn4_checkbox_c);
        CheckBox ansFourCheckBoxD= (CheckBox) findViewById(R.id.qtn4_checkbox_d);

        boolean hasCorrectAns4A= ansFourCheckBoxA.isChecked();
        boolean hasCorrectAns4B= ansFourCheckBoxB.isChecked();
        boolean hasCorrectAns4C= ansFourCheckBoxC.isChecked();
        boolean hasCorrectAns4D= ansFourCheckBoxD.isChecked();
        if(!hasCorrectAns4A && hasCorrectAns4B && hasCorrectAns4C && hasCorrectAns4D){

            answer4Mark=2;
        }


        // question five answer options
        boolean correctAns5;
        RadioButton ansFiveARadioButtonA= (RadioButton) findViewById(R.id.qtn_5_radio_button_a);
        correctAns5 = ansFiveARadioButtonA.isChecked();
        if (correctAns5) {
            answer5Mark = 2;
        }


        // question six answer options

        // question four answer options
        CheckBox ansSixCheckBoxA= (CheckBox) findViewById(R.id.qtn6_checkbox_a);
        CheckBox ansSixCheckBoxB= (CheckBox) findViewById(R.id.qtn6_checkbox_b);
        CheckBox ansSixCheckBoxC= (CheckBox) findViewById(R.id.qtn6_checkbox_c);
        CheckBox ansSixCheckBoxD= (CheckBox) findViewById(R.id.qtn6_checkbox_d);
        CheckBox ansSixCheckBoxE= (CheckBox) findViewById(R.id.qtn6_checkbox_e);

        //  CheckBox chocolateCheckBox=findViewById(R.id.chocolate_checkbox);
        boolean hasCorrectAns6A= ansSixCheckBoxA.isChecked();
        boolean hasCorrectAns6B= ansFourCheckBoxB.isChecked();
        boolean hasCorrectAns6C= ansFourCheckBoxC.isChecked();
        boolean hasCorrectAns6D= ansFourCheckBoxD.isChecked();

          if(hasCorrectAns6A && hasCorrectAns6B && hasCorrectAns6C && hasCorrectAns6D){

              answer6Mark=2;
          }

        // questions seven answers options
        boolean correctAns7;

        RadioButton ansSevenARadioButtonA= (RadioButton) findViewById(R.id.qtn_7_radio_button_a);

        correctAns7=ansSevenARadioButtonA.isChecked();

        if(correctAns7){
            answer7Mark=2;
        }

        // questions eight answers options
        boolean correctAns8;
        RadioButton ansEightARadioButtonA= (RadioButton) findViewById(R.id.qtn_8_radio_button_a);
        correctAns8=ansEightARadioButtonA.isChecked();

        if(correctAns8){
            answer8Mark=2;
        }

        // questions nine answers options
        boolean correctAns9;
        RadioButton ansNineARadioButtonB= (RadioButton) findViewById(R.id.qtn_9_radio_button_b);
        correctAns9=ansNineARadioButtonB.isChecked();

        if(correctAns9){
            answer9Mark=2;
        }


        // questions eight answers options
        boolean correctAns10;
        RadioButton ansTenARadioButtonA= (RadioButton) findViewById(R.id.qtn_10_radio_button_a);
          correctAns10=ansTenARadioButtonA.isChecked();

          if(correctAns10){
              answer10Mark=2;

          }
      //  Total calculated marks for the quiz
      totalMarks = answer1Mark+answer2Mark+answer3Mark+answer4Mark+answer5Mark+answer6Mark+answer7Mark+answer8Mark+answer9Mark+answer10Mark;

   displayResult(totalMarks);



    }

    /**
     * this method displays the final result of the quiz using Toast method
     * @param finalResult
     */
    public  void  displayResult(int finalResult){

        finaResultsDisplay = getString(R.string.display_message)+' '+ finalResult + ' '+ getString(R.string.total_quiz_marks);

        Context context = getApplicationContext();
        int duration = Toast.LENGTH_LONG;
        for(int i=0;i<30;i++) {
            Toast toast = Toast.makeText(context, finaResultsDisplay, duration);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
    }


}
